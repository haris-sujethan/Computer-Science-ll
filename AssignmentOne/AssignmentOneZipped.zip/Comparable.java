//Haris Sujethan 501088408

public interface Comparable {

    public Boolean isDiffrentThan(Comparable other);
}