The File I/O code or Question D  in my assignment is written as a bunch of comments. 

If you view lines 464-577, that is my code for question d. 
I was facing some bugs, and I didn't want it to affect the rest of my assignment from running. 

The overall logic is there, and the code is basically finished. If you
could please uncomment this code and look at it, that would be great. Thank you.

Also, the stats function or question f works, but it is not printed in order.